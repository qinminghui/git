.. _changelog:

+++++++++
Changelog
+++++++++

.. miscnews:: ../../Misc/NEWS
